jQuery(document).ready(function($) {
	$('.notification-post').quovolver();
	$("#sn-notification").removeClass("js-hide");
});