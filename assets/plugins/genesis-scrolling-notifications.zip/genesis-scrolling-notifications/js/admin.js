jQuery(document).ready(function($) {   
    $('#gsn-bg-color').wpColorPicker();
}); 