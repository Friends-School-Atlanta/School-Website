<?php
/**
 * Do NOT edit the css files here or put custom styles in here! They will be deleted on 'Genesis Printstyle Plus' updates!
 *
 * For custom styles for 'Genesis Printstyle Plus'
 *   please add them to your active child theme's stylesheet (you may need '!important' maybe for a few rules...)
 *   and name the files this way:
 *     'print-additions.css'  --> for additions to this plugin's styles!
 *     'gpsp-print.css'       --> to replace this plugin's styles!
 */