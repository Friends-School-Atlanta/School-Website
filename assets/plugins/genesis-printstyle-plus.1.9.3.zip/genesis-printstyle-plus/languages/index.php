<?php
/**
 * Do not put custom translations here. They will be deleted on 'Genesis Printstyle Plus' updates!
 *
 * Keep custom 'Genesis Printstyle Plus' translations in '/wp-content/languages/genesis-printstyle-plus/'
 */