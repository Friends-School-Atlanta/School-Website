<?php
/*  Uninstall Genesis Accessible Dropdown Menu

	Version: 1.0
 
	License: GPL-2.0+
	License URI: http://www.opensource.org/licenses/gpl-license.php

 */
 
if( !defined( 'ABSPATH') && !defined('WP_UNINSTALL_PLUGIN') )
    exit();


?>